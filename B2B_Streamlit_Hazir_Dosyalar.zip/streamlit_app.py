import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from pathlib import Path

st.set_page_config(page_title="B2B Book Distribution | Decision Dashboard", page_icon="📚", layout="wide")

st.markdown("""<style>
.block-container {padding-top: 1.4rem; padding-bottom: 2rem;}
h1,h2,h3 {letter-spacing: -.02em;}
[data-testid='stMetric'] {background: #f3f6fa; border: 1px solid #e5e9ef; padding: 15px 18px; border-radius: 12px;}
</style>""", unsafe_allow_html=True)

DATA = Path(__file__).parent / "B2B_Transaction_Data_.xlsx"

@st.cache_data(show_spinner="Reading and cleaning transaction data …")
def load_data():
    raw = pd.read_excel(DATA, engine="openpyxl")
    raw["InvoiceDate"] = pd.to_datetime(raw["InvoiceDate"], errors="coerce")
    raw_issues = {
        "Original rows": len(raw),
        "Missing city": int(raw["City"].isna().sum()),
        "Missing category": int(raw["Category"].isna().sum()),
        "Missing quantity": int(raw["Quantity"].isna().sum()),
        "Exact duplicates retained": int(raw.duplicated().sum()),
        "Non-positive net price": int((raw["NetPrice"] <= 0).sum()),
    }
    clean = raw.copy()
    clean["City"] = clean["City"].fillna("Unknown")
    clean["Category"] = clean["Category"].fillna("Unknown")
    clean = clean.loc[
        clean["InvoiceDate"].notna()
        & clean["CustomerID"].notna()
        & clean["InvoiceNo"].notna()
        & clean["Quantity"].notna()
        & (clean["Quantity"] > 0)
        & (clean["NetPrice"] > 0)
    ].copy()
    # Assumption: NetPrice is the net per-unit selling price.
    clean["TotalSales"] = clean["Quantity"] * clean["NetPrice"]
    clean["YearMonth"] = clean["InvoiceDate"].dt.to_period("M").astype(str)
    raw_issues["Clean rows"] = len(clean)
    raw_issues["Excluded rows"] = len(raw) - len(clean)
    return clean, raw_issues

st.title("📚 B2B Book Distribution | Decision Support Dashboard")
st.caption("Sales, customer, and supply-chain analytics based on 2020 transaction data")

if not DATA.exists():
    st.error("The dataset B2B_Transaction_Data_.xlsx must be in the same folder as streamlit_app.py.")
    st.stop()

try:
    df, quality = load_data()
except Exception as exc:
    st.error(f"Dataset could not be opened: {exc}")
    st.stop()

st.sidebar.header("Filters")
start_default = df["InvoiceDate"].min().date()
end_default = df["InvoiceDate"].max().date()
dates = st.sidebar.date_input("Date range", value=(start_default, end_default), min_value=start_default, max_value=end_default)
cities = st.sidebar.multiselect("Cities", sorted(df["City"].astype(str).unique().tolist()), placeholder="All cities")
categories = st.sidebar.multiselect("Categories", sorted(df["Category"].astype(str).unique().tolist()), placeholder="All categories")

filtered = df
if isinstance(dates, (tuple, list)) and len(dates) == 2:
    filtered = filtered.loc[filtered["InvoiceDate"].dt.date.between(dates[0], dates[1])]
if cities:
    filtered = filtered.loc[filtered["City"].isin(cities)]
if categories:
    filtered = filtered.loc[filtered["Category"].isin(categories)]

if filtered.empty:
    st.warning("No transactions match the selected filters. Adjust the sidebar filters.")
    st.stop()

revenue = filtered["TotalSales"].sum()
orders = filtered["InvoiceNo"].nunique()
customers = filtered["CustomerID"].nunique()
units = filtered["Quantity"].sum()

m1, m2, m3, m4 = st.columns(4)
m1.metric("Revenue (dataset units)", f"{revenue:,.0f}")
m2.metric("Unique invoices", f"{orders:,}")
m3.metric("Customers", f"{customers:,}")
m4.metric("Units sold", f"{units:,.0f}")

sales_tab, customers_tab, supply_tab, forecast_tab, quality_tab = st.tabs(
    ["📈 Sales Overview", "👥 Customer & Marketing", "📦 Supply Chain", "🔮 Forecast & Insights", "🧹 Data Quality"]
)

with sales_tab:
    monthly = filtered.groupby("YearMonth", as_index=False)["TotalSales"].sum().sort_values("YearMonth")
    c1, c2 = st.columns([1.3, 1])
    with c1:
        st.subheader("Monthly revenue")
        st.plotly_chart(px.line(monthly, x="YearMonth", y="TotalSales", markers=True, labels={"YearMonth":"Month", "TotalSales":"Revenue"}), use_container_width=True)
    with c2:
        st.subheader("Top 10 categories by revenue")
        category = filtered.groupby("Category", as_index=False)["TotalSales"].sum().nlargest(10, "TotalSales")
        st.plotly_chart(px.bar(category.sort_values("TotalSales"), x="TotalSales", y="Category", orientation="h", labels={"TotalSales":"Revenue"}), use_container_width=True)
    st.subheader("Top 10 cities by revenue")
    city = filtered.groupby("City", as_index=False)["TotalSales"].sum().nlargest(10, "TotalSales")
    st.plotly_chart(px.bar(city.sort_values("TotalSales"), x="TotalSales", y="City", orientation="h"), use_container_width=True)
    if len(monthly) >= 2:
        maxrow = monthly.loc[monthly["TotalSales"].idxmax()]
        minrow = monthly.loc[monthly["TotalSales"].idxmin()]
        st.info(f"Highest observed monthly revenue: {maxrow['YearMonth']} ({maxrow['TotalSales']:,.0f}). Lowest: {minrow['YearMonth']} ({minrow['TotalSales']:,.0f}).")

with customers_tab:
    customer = filtered.groupby("CustomerID").agg(
        Revenue=("TotalSales", "sum"),
        Orders=("InvoiceNo", "nunique"),
        LastPurchase=("InvoiceDate", "max")
    ).reset_index()
    customer["AverageInvoiceRevenue"] = customer["Revenue"] / customer["Orders"].replace(0, np.nan)
    a, b = st.columns(2)
    with a:
        st.subheader("Top 15 customers by revenue")
        top = customer.nlargest(15, "Revenue").sort_values("Revenue")
        st.plotly_chart(px.bar(top, x="Revenue", y="CustomerID", orientation="h"), use_container_width=True)
    with b:
        st.subheader("Purchase frequency distribution")
        st.plotly_chart(px.histogram(customer, x="Orders", nbins=45, labels={"Orders":"Unique invoices per customer"}), use_container_width=True)
    top10_share = customer.nlargest(10, "Revenue")["Revenue"].sum() / revenue * 100
    st.info(f"The 10 highest-revenue customers account for {top10_share:.1f}% of sales under the current filters. Consider account-management prioritization, while checking customer concentration risk.")
    customer_id = st.selectbox("Inspect customer", options=customer.sort_values("CustomerID")["CustomerID"].tolist())
    st.dataframe(customer.loc[customer["CustomerID"] == customer_id], use_container_width=True, hide_index=True)
    st.download_button("Download customer summary", customer.to_csv(index=False).encode("utf-8-sig"), "customer_summary.csv", "text/csv")

with supply_tab:
    products = filtered.groupby(["StockCode", "Description"], as_index=False).agg(
        Units=("Quantity", "sum"), Revenue=("TotalSales", "sum"),
        Invoices=("InvoiceNo", "nunique")
    )
    order_by = st.radio("Rank products by", ["Units", "Revenue"], horizontal=True)
    top_products = products.nlargest(15, order_by).sort_values(order_by)
    st.subheader(f"Top 15 products by {order_by.lower()}")
    top_products["ProductLabel"] = top_products["Description"].astype(str).str.slice(0, 52) + " (" + top_products["StockCode"].astype(str) + ")"
    st.plotly_chart(px.bar(top_products, x=order_by, y="ProductLabel", orientation="h", labels={"ProductLabel":"Product"}), use_container_width=True)
    st.subheader("High-demand products — planning shortlist")
    st.dataframe(products.nlargest(20, "Units"), hide_index=True, use_container_width=True)
    st.caption("Demand priority reflects historical units sold; stock levels, lead times, and actual stockouts are unavailable. This is not a reorder-point calculation.")
    st.download_button("Download product demand summary", products.to_csv(index=False).encode("utf-8-sig"), "product_demand.csv", "text/csv")

with forecast_tab:
    st.subheader("Simple revenue baseline forecast")
    st.caption("Three-month moving-average baseline, not a validated predictive model. Use as an indicative planning scenario only.")
    monthly_full = filtered.groupby("YearMonth")["TotalSales"].sum().sort_index()
    if len(monthly_full) >= 3:
        last_3_avg = float(monthly_full.iloc[-3:].mean())
        last_period = pd.Period(monthly_full.index[-1], freq="M")
        next_months = [(last_period + i).strftime("%Y-%m") for i in range(1, 4)]
        pred = pd.DataFrame({"YearMonth": next_months, "TotalSales": [last_3_avg]*3, "Type": "Baseline forecast"})
        observed = monthly_full.reset_index().rename(columns={0:"TotalSales"})
        observed.columns = ["YearMonth", "TotalSales"]
        observed["Type"] = "Observed"
        plot_df = pd.concat([observed, pred], ignore_index=True)
        fig = px.line(plot_df, x="YearMonth", y="TotalSales", color="Type", markers=True)
        st.plotly_chart(fig, use_container_width=True)
        st.metric("Baseline monthly forecast", f"{last_3_avg:,.0f}")
        st.caption("Forecast is based on the selected months. A one-year dataset cannot establish reliable seasonal patterns.")
    else:
        st.warning("Select at least three observed months to calculate a moving-average baseline.")
    category_rev = filtered.groupby("Category")["TotalSales"].sum().sort_values(ascending=False)
    if not category_rev.empty:
        st.info(f"Commercial opportunity: '{category_rev.index[0]}' leads category revenue within the selected filters. Review availability and promotions for this category.")

with quality_tab:
    st.subheader("Cleaning audit")
    st.dataframe(pd.DataFrame([{"Check": k, "Value": v} for k, v in quality.items()]), hide_index=True, use_container_width=True)
    st.markdown("""**Methodology**
- Missing city/category labels are replaced with `Unknown`.
- Rows with missing/non-positive quantity or non-positive net price are excluded from positive-sales analysis.
- Exact duplicate rows are **retained**, as identical book lines on one invoice may represent separate legitimate sales. This assumption may overstate revenue if they are data-entry duplicates.
- `TotalSales = Quantity × NetPrice`, assuming `NetPrice` is net per-unit price; the source does not supply an explicit data dictionary.
- The dataset covers 2020 only. No real-time stock balances, procurement lead times, margins, or marketing spend are present.
""")
    st.download_button("Download filtered transactions", filtered.to_csv(index=False).encode("utf-8-sig"), "filtered_transactions.csv", "text/csv")

st.caption("ISL 467E • Management Engineering Applications with Python • Exploratory decision-support prototype")
