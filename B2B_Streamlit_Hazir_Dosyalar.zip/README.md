# B2B Book Distributor Decision Support Dashboard

## Run locally

1. Put `B2B_Transaction_Data_.xlsx` in this folder.
2. `python -m pip install -r requirements.txt`
3. `python -m streamlit run streamlit_app.py`

## Deploy

Push `streamlit_app.py`, `requirements.txt`, and `B2B_Transaction_Data_.xlsx` to a GitHub repository. Connect the repository in Streamlit Community Cloud; select `streamlit_app.py` as the main file. Verify charts load and share the public link.

## Notes

The dashboard assumes `NetPrice` is a net unit price, retains exact duplicate transaction lines, and excludes non-positive sales. Forecasts are simple three-month moving-average baselines and are not validated predictive models. The source contains no inventory balances or lead times.
